How to install
==============

Windows & Linux
---------------
Locate your Besiege installation. If you installed Besiege via Steam, this will usually be in C:\Program Files (x86)\Steam\steamapps\common\Besiege. I will from now on refer to this directory as simply Besiege in any paths.
Copy the file Assembly-UnityScript.dll into Besiege/Besiege_Data/Managed. When asked, choose to replace the original file. You may also want to make a backup of the original file before doing this.
Then create the folder Besiege/Besiege_Data/Mods. Copy SpaarModLoader.dll and the Resources folder into it. You will also place any mods you install into this folder.

Mac OS X
--------
Locate your Besiege installation (Besiege.app, right-click on Besiege and choose Show Package Content). I will from now on refer to this directory as simply Besiege in any paths.
Copy the file Assembly-UnityScript.dll into Besiege/Contents/Data/Managed. When asked, choose to replace the original file. You may also want to make a backup of the original file before doing this.
Then create the folder Besiege/Contents/Mods. Copy SpaarModLoader.dll and the Resources folder into it. You will also place any mods you install into this folder.

That's it, the mod loader should now be installed. If you have any problems or questions, just ask on the forum and I will do my best to help.