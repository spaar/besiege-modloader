0.3
===
- Add a console command system
- Add console message filtering via console commands
- [Developer Build] Add tag and layer display to object explorer (only shown if not 'Untagged' or layer 0 respectively)

0.2.2
=====
- Update for Besiege v0.09

0.2.1
=====
- Make it possible for mods to have optional dependencies again
- Remove object explorer key settings from non-developer builds

0.2
=====
- Fixed console autoscrolling
- Introduce seperate developer and end-user builds
- Improve performance
- Add new, improved way of loading mods
- Remappable keys
- Add mod examples for developers
- Fixed various small bugs

0.1.3
=====
- Updated for Besiege v0.08
- Fixed console for large number of messages

0.1.2
=====
- Fixed bug where mods were loaded twice
- Added a way for mods to be notified when the simulation starts

0.1.1
=====
Added Mac support thanks to Mtschroll

0.1
===
Initial Release